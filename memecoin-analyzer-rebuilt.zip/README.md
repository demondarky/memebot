# Axiom & Pump.fun Memecoin Analyzer

A terminal-style dashboard for exploring Solana memecoins from pump.fun and Axiom: live token data via DexScreener, an AI-assisted rug-checker, analytics charts, and a paper-trading terminal with an approval-gated auto-trade watcher.

## What this is (and isn't)

- **Real wallet connection** via Phantom/Solflare through the official `@solana/wallet-adapter`. Your private key and seed phrase never leave your wallet extension — this app only ever sees your public address.
- **No real trading is executed by this app.** "Buy"/"Snipe" actions open a notional paper position so you can practice stop-loss / take-profit / trailing-stop logic. To execute a real trade, use your wallet's own swap feature or a tool like Jupiter directly.
- **No login system, no user database, no admin panel.** There are no accounts and nothing is stored server-side about you.
- **Auto-trade watcher, not auto-trade executor.** When you enable it, it only watches for conditions you configure (e.g. bonding curve crossing a threshold) and queues an approval for you to review — it never signs or sends a transaction on its own.

## Run Locally

**Prerequisites:** Node.js

1. Install dependencies:
   `npm install`
2. Set `GEMINI_API_KEY` in your environment (see `.env.example`) for AI-assisted rug-check analysis. Without it, the rug-checker falls back to algorithmic scoring.
3. Run the app:
   `npm run dev`

## Architecture notes

- `server.ts` — Express server. Only handles public, read-only data: DexScreener token feeds, Gemini-assisted analysis, and read-only balance lookups by public key. It never receives a private key.
- `src/lib/SolanaWalletProvider.tsx` / `useSolanaWallet.ts` — Wraps the real Solana wallet-adapter so connection/balance state comes from your actual wallet extension.
- `src/components/` — Dashboard UI: token cards, rug-checker, analytics, terminal, and the wallet connect modal.
