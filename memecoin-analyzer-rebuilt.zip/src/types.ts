export interface MemeCoin {
  address: string;
  name: string;
  symbol: string;
  origin: "axiom" | "pump.fun";
  priceUsd: number;
  priceChange24h: number;
  volume24h: number;
  liquidityUsd: number;
  marketCap: number;
  imageUrl: string;
  potential: string; // e.g. "12.5x"
  winRate: number;    // e.g. 84 (representing individual win chance percentage)
  rugScore: number;   // e.g. 89 (safety rating, 0 to 100)
  securityFlags: string[];
  websites?: string[];
  twitter?: string;
  telegram?: string;
  description?: string;
  verdict?: string;
}

// Wallet state is derived entirely from the connected browser extension
// (Phantom / Solflare via @solana/wallet-adapter). No private key is ever
// held in app state, local storage, or sent to the server.
export interface WalletState {
  connected: boolean;
  walletName: string | null;
  publicKey: string | null;
  balanceSol: number;
}

export interface SimulationTx {
  id: string;
  timestamp: number;
  tokenName: string;
  tokenSymbol: string;
  type: "buy" | "sell" | "rug_check" | "auto_buy_pending" | "auto_sell_pending";
  amountSol: number;
  walletAddr: string;
  status: "success" | "pending" | "awaiting_approval";
  signature?: string;
}

export interface GeminiAuditResult {
  address: string;
  name: string;
  symbol: string;
  potentialMultiplier: string;
  winProbability: number;
  auditScore: number;
  securityWarnings: string[];
  liquidityRating: string;
  analysisText: string;
  verdict: string;
}

export interface ActiveTrade {
  id: string;
  tokenAddress: string;
  name: string;
  symbol: string;
  buyPriceUsd: number;
  currentPriceUsd: number;
  amountSol: number;
  amountTokens: number;
  maxPriceUsd: number; // Highest price reached (for trailing stop-loss calculation)
  stopLossPercent: number; // e.g., -10 for -10% stop loss
  trailingStopPercent: number | null; // e.g., 5 for 5% trailing stop loss
  takeProfitPercent: number; // e.g. 50 for 50% target
  unrealizedPnlPercent: number;
}

// Auto-trade here means condition-watching only. When a configured condition
// fires, it creates a PendingApproval the user must confirm in their wallet
// extension. Nothing ever signs or sends on its own.
export interface AutoTradeSettings {
  autoBuyBondingCurve: boolean;
  bondingCurveThreshold: number; // e.g. 75 for 75%
  amountSol: number;
  stopLossPercent: number;
  trailingStopPercent: number | null;
  takeProfitPercent: number; // custom take profit target
  targetLowPotentialOnly: boolean; // 2x to 5x only
}

export interface PendingApproval {
  id: string;
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  action: "buy" | "sell";
  amountSol: number;
  reason: string; // e.g. "Bonding curve crossed 75% threshold"
  createdAt: number;
}

export interface PriceAlert {
  id: string;
  tokenAddress: string;
  tokenSymbol: string;
  tokenName: string;
  targetPriceUsd: number;
  condition: "above" | "below";
  createdAt: number;
  triggered: boolean;
}

export interface CompletedTrade {
  id: string;
  tokenAddress: string;
  tokenName: string;
  symbol: string;
  amountSol: number;
  amountTokens: number;
  buyPriceUsd: number;
  sellPriceUsd: number;
  pnlSol: number;
  pnlPercent: number;
  timestamp: number;
  isAuto: boolean;
  reason: string;
}
