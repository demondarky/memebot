import { useEffect, useState, useCallback } from "react";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { WalletState } from "../types";

// Derives our app-level WalletState purely from the real wallet-adapter
// connection. The balance is fetched read-only, either directly from the
// RPC connection the adapter already has, or via our server's safe
// public-key-only balance endpoint as a fallback. No private key is ever
// read, stored, or transmitted by this hook.
export function useSolanaWallet(): WalletState & { refreshBalance: () => Promise<void> } {
  const { publicKey, connected, wallet } = useWallet();
  const { connection } = useConnection();
  const [balanceSol, setBalanceSol] = useState(0);

  const refreshBalance = useCallback(async () => {
    if (!publicKey) {
      setBalanceSol(0);
      return;
    }
    try {
      const lamports = await connection.getBalance(publicKey);
      setBalanceSol(parseFloat((lamports / 1e9).toFixed(4)));
    } catch (err) {
      // Fall back to the server's read-only balance endpoint if the
      // client-side RPC call fails (e.g. rate limiting).
      try {
        const res = await fetch(`/api/wallet/balance/${publicKey.toBase58()}`);
        const data = await res.json();
        if (data.success) setBalanceSol(data.balanceSol);
      } catch {
        // leave balance as-is; UI shows last known value
      }
    }
  }, [publicKey, connection]);

  useEffect(() => {
    refreshBalance();
    if (!publicKey) return;
    const interval = setInterval(refreshBalance, 20000);
    return () => clearInterval(interval);
  }, [publicKey, refreshBalance]);

  return {
    connected,
    walletName: wallet?.adapter.name || null,
    publicKey: publicKey ? publicKey.toBase58() : null,
    balanceSol,
    refreshBalance,
  };
}
