import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldAlert,
  Check,
  Copy,
  TrendingUp,
  Layers,
  Wifi,
  Activity,
} from "lucide-react";
import { MemeCoin, SimulationTx, ActiveTrade, AutoTradeSettings, PriceAlert, CompletedTrade, PendingApproval } from "./types";
import WalletModal from "./components/WalletModal";
import RugChecker from "./components/RugChecker";
import AnalyticsPanel from "./components/AnalyticsPanel";
import ExploreTab from "./components/ExploreTab";
import TerminalTab from "./components/TerminalTab";
import { useSolanaWallet } from "./lib/useSolanaWallet";
import { useWallet } from "@solana/wallet-adapter-react";

const INITIAL_NEWLY_LAUNCHED = [
  {
    address: "7FCmpU98asdfgJ98fsDF8sd7Fs9D8sF89ySDF98",
    name: "Axiom Cyber Doge",
    symbol: "ACD",
    origin: "axiom" as const,
    priceUsd: 0.00125,
    priceChange24h: 42.1,
    volume24h: 312000,
    liquidityUsd: 18500,
    marketCap: 125000,
    imageUrl: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=150&auto=format&fit=crop&q=80",
    potential: "3.2x",
    winRate: 81,
    rugScore: 92,
    securityFlags: ["Mint Authority Revoked", "LP Burned 100%", "No Dev Shares"],
    bondingCurveProgress: 45,
  },
  {
    address: "pumpFunZk78aSdfH8dfvD8sF89uSDF89sFD98sF",
    name: "Pepe Quantum Speed",
    symbol: "PQS",
    origin: "pump.fun" as const,
    priceUsd: 0.000045,
    priceChange24h: 94.2,
    volume24h: 215000,
    liquidityUsd: 12400,
    marketCap: 45000,
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80",
    potential: "4.8x",
    winRate: 74,
    rugScore: 81,
    securityFlags: ["Mint Authority Revoked", "Freeze Disabled", "0% Dev Holdings"],
    bondingCurveProgress: 22,
  },
  {
    address: "AxiMoD8sf9SDF89sFD98sFu49R98ASDF8asd7Fs",
    name: "Zero Proof Sol",
    symbol: "ZPS",
    origin: "axiom" as const,
    priceUsd: 0.0028,
    priceChange24h: 112.5,
    volume24h: 489000,
    liquidityUsd: 42000,
    marketCap: 280000,
    imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=150&auto=format&fit=crop&q=80",
    potential: "2.4x",
    winRate: 88,
    rugScore: 96,
    securityFlags: ["Mint Authority Revoked", "Freeze Disabled", "Liquidity Locked"],
    bondingCurveProgress: 72,
  }
];

export default function App() {
  const wallet = useSolanaWallet();
  const { disconnect } = useWallet();

  const [tokens, setTokens] = useState<MemeCoin[]>([]);
  const [globalWinRate, setGlobalWinRate] = useState<number>(76.4);
  const [loading, setLoading] = useState<boolean>(true);
  const [demoMode, setDemoMode] = useState<boolean>(true);

  const [tab, setTab] = useState<"explore" | "rug_checker" | "terminal" | "analytics">("explore");
  const [originFilter, setOriginFilter] = useState<"all" | "axiom" | "pump.fun">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState(false);

  const [txLogs, setTxLogs] = useState<SimulationTx[]>([]);
  const [notifications, setNotifications] = useState<Array<{ id: string; msg: string; type: "success" | "info" }>>([]);
  const [terminalSubTab, setTerminalSubTab] = useState<"logs" | "trades" | "approvals">("logs");
  const [tradeSortField, setTradeSortField] = useState<keyof CompletedTrade>("timestamp");
  const [tradeSortOrder, setTradeSortOrder] = useState<"asc" | "desc">("desc");
  const [tradePage, setTradePage] = useState(1);

  const [activeTrades, setActiveTrades] = useState<ActiveTrade[]>(() => {
    try {
      const saved = localStorage.getItem("active_trades_v1");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [completedTrades, setCompletedTrades] = useState<CompletedTrade[]>(() => {
    try {
      const saved = localStorage.getItem("completed_trades_v1");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("completed_trades_v1", JSON.stringify(completedTrades));
  }, [completedTrades]);
  useEffect(() => {
    localStorage.setItem("active_trades_v1", JSON.stringify(activeTrades));
  }, [activeTrades]);

  const buyingAddressesRef = useRef<Set<string>>(new Set());
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>(() => {
    try {
      const saved = localStorage.getItem("price_alerts_v1");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  useEffect(() => {
    localStorage.setItem("price_alerts_v1", JSON.stringify(priceAlerts));
  }, [priceAlerts]);

  const [newlyLaunched] = useState(INITIAL_NEWLY_LAUNCHED);

  // Auto-trade engine: this WATCHES conditions only. When a condition fires,
  // it creates a PendingApproval that the user must confirm themselves via
  // their connected wallet extension. Nothing is ever signed or sent without
  // that explicit, per-trade human approval.
  const [autoTradeEngineEnabled, setAutoTradeEngineEnabled] = useState<boolean>(false);
  const [snipeSettings, setSnipeSettings] = useState<AutoTradeSettings>({
    autoBuyBondingCurve: false,
    bondingCurveThreshold: 75,
    amountSol: 0.2,
    stopLossPercent: 15,
    trailingStopPercent: 5,
    takeProfitPercent: 50,
    targetLowPotentialOnly: true
  });
  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([]);

  const [hudExpanded, setHudExpanded] = useState(false);

  const [marketData, setMarketData] = useState<{
    solPriceUsd: number;
    solPriceChange24h: number;
    memecoins: MemeCoin[];
  } | null>(null);

  const fetchMarketData = async () => {
    try {
      const res = await fetch("/api/market-prices");
      const data = await res.json();
      if (data.success) {
        setMarketData(data);
      }
    } catch (err) {
      console.log("Failed to load live market prices:", err);
    }
  };

  const addToast = (msg: string, type: "success" | "info" = "success") => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications(prev => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  const copyPublicKey = () => {
    if (wallet.publicKey) {
      navigator.clipboard.writeText(wallet.publicKey);
      setCopiedAddr(true);
      setTimeout(() => setCopiedAddr(false), 2000);
    }
  };

  const checkPriceAlerts = (latestTokens: MemeCoin[]) => {
    setPriceAlerts((prevAlerts) => {
      if (prevAlerts.length === 0) return prevAlerts;
      let alertsChanged = false;
      const updatedAlerts = prevAlerts.map((alert) => {
        if (alert.triggered) return alert;
        let matchingToken = latestTokens.find(
          (t) => t.address.toLowerCase() === alert.tokenAddress.toLowerCase()
        );
        if (!matchingToken) {
          matchingToken = newlyLaunched.find(
            (t) => t.address.toLowerCase() === alert.tokenAddress.toLowerCase()
          ) as any;
        }
        if (matchingToken) {
          const currentPrice = matchingToken.priceUsd;
          const target = alert.targetPriceUsd;
          const isAbove = alert.condition === "above";
          const isHit = isAbove ? currentPrice >= target : currentPrice <= target;
          if (isHit) {
            alertsChanged = true;
            addToast(`🚨 TARGET MET: ${alert.tokenSymbol} reached $${currentPrice < 0.0001 ? currentPrice.toFixed(8) : currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 5 })} (Target: $${target < 0.0001 ? target.toFixed(8) : target.toLocaleString()})!`, "success");
            return { ...alert, triggered: true };
          }
        }
        return alert;
      });
      return alertsChanged ? updatedAlerts : prevAlerts;
    });
  };

  const handleAddPriceAlert = (token: MemeCoin, targetPrice: number, condition: "above" | "below") => {
    const newAlert: PriceAlert = {
      id: Math.random().toString(36).substring(2, 9),
      tokenAddress: token.address,
      tokenSymbol: token.symbol,
      tokenName: token.name,
      targetPriceUsd: targetPrice,
      condition,
      createdAt: Date.now(),
      triggered: false
    };
    setPriceAlerts(prev => [newAlert, ...prev]);
    addToast(`🔔 Price alert registered for ${token.symbol} at $${targetPrice < 0.0001 ? targetPrice.toFixed(8) : targetPrice.toFixed(4)}`, "success");
  };

  const handleRemovePriceAlert = (id: string) => {
    setPriceAlerts(prev => prev.filter(a => a.id !== id));
  };

  // Paper-trade position close: this is a notional P&L tracker only. It never
  // touches a real wallet balance or sends a transaction — it just records
  // hypothetical entry/exit so the stop-loss / take-profit math is usable
  // for practicing risk management before trading for real.
  const closePaperPosition = (trade: ActiveTrade, isAuto: boolean, reason: string) => {
    setActiveTrades((prev) => prev.filter((t) => t.id !== trade.id));
    const pnlPercent = trade.unrealizedPnlPercent;
    const pnlSol = parseFloat((trade.amountSol * (pnlPercent / 100)).toFixed(4));
    const newCompletedTrade: CompletedTrade = {
      id: trade.id || Math.random().toString(36).substring(2, 9),
      tokenAddress: trade.tokenAddress,
      tokenName: trade.name,
      symbol: trade.symbol,
      amountSol: trade.amountSol,
      amountTokens: trade.amountTokens,
      buyPriceUsd: trade.buyPriceUsd,
      sellPriceUsd: trade.currentPriceUsd,
      pnlSol,
      pnlPercent,
      timestamp: Date.now(),
      isAuto,
      reason: reason || "Manual paper close"
    };
    setCompletedTrades((prev) => [newCompletedTrade, ...prev]);
    const isGain = pnlPercent >= 0;
    addToast(
      isAuto
        ? `📝 PAPER AUTO-CLOSE: ${reason}. Notional P&L ${isGain ? "+" : ""}${pnlPercent}%`
        : `📝 Paper position closed: ${trade.symbol} (${isGain ? "+" : ""}${pnlPercent}%)`,
      isGain ? "success" : "info"
    );
  };

  const loadData = async (isDemo: boolean, silent = false) => {
    if (!silent) setLoading(true);
    try {
      const response = await fetch(`/api/memecoins?demo=${isDemo}`);
      const data = await response.json();
      if (data.success) {
        setTokens(data.tokens);
        setGlobalWinRate(data.globalWinRate);
        checkPriceAlerts(data.tokens);

        setActiveTrades((prevTrades) => {
          if (prevTrades.length === 0) return prevTrades;
          return prevTrades.map((trade) => {
            const match = data.tokens.find((t: MemeCoin) => t.address.toLowerCase() === trade.tokenAddress.toLowerCase());
            if (!match) return trade;
            const updatedPrice = match.priceUsd;
            const updatedMaxPrice = Math.max(trade.maxPriceUsd, updatedPrice);
            const unrealizedPnlPercent = parseFloat((((updatedPrice - trade.buyPriceUsd) / trade.buyPriceUsd) * 100).toFixed(1));

            if (unrealizedPnlPercent <= -Math.abs(trade.stopLossPercent)) {
              setTimeout(() => closePaperPosition(trade, true, `STOP LOSS HIT AT ${unrealizedPnlPercent}%`), 10);
            } else if (unrealizedPnlPercent >= trade.takeProfitPercent) {
              setTimeout(() => closePaperPosition(trade, true, `TAKE PROFIT HIT AT +${unrealizedPnlPercent}%`), 10);
            } else if (trade.trailingStopPercent !== null) {
              const dropFromMax = ((updatedMaxPrice - updatedPrice) / updatedMaxPrice) * 100;
              if (dropFromMax >= Math.abs(trade.trailingStopPercent)) {
                setTimeout(() => closePaperPosition(trade, true, `TRAILING STOP (Dropped ${dropFromMax.toFixed(1)}% from peak)`), 10);
              }
            }

            return { ...trade, currentPriceUsd: updatedPrice, maxPriceUsd: updatedMaxPrice, unrealizedPnlPercent };
          });
        });
      }
    } catch (err) {
      console.log("Failed to load pool tokens: ", err);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const loadLogs = async () => {
    try {
      const res = await fetch("/api/wallet-logs");
      const data = await res.json();
      if (data.success) setTxLogs(data.logs);
    } catch (err) {
      console.log("Failed to load tx logs:", err);
    }
  };

  useEffect(() => {
    loadData(demoMode);
    loadLogs();
    fetchMarketData();
    const dataTimer = setInterval(() => loadData(demoMode, true), 12000);
    const marketTimer = setInterval(fetchMarketData, 15000);
    return () => {
      clearInterval(dataTimer);
      clearInterval(marketTimer);
    };
  }, [demoMode]);

  // Manual "snipe" / paper buy: records a notional position the user can
  // track with stop-loss / take-profit, without moving any real funds.
  const handleBuySimulate = (token: MemeCoin, amount: number) => {
    const numTokens = (amount * 5000000) / (token.priceUsd || 0.001);
    const newTrade: ActiveTrade = {
      id: `trade-${Math.random().toString(36).substring(2, 9)}`,
      tokenAddress: token.address,
      name: token.name,
      symbol: token.symbol,
      buyPriceUsd: token.priceUsd,
      currentPriceUsd: token.priceUsd,
      amountSol: amount,
      amountTokens: numTokens,
      maxPriceUsd: token.priceUsd,
      stopLossPercent: snipeSettings.stopLossPercent,
      trailingStopPercent: snipeSettings.trailingStopPercent,
      takeProfitPercent: snipeSettings.takeProfitPercent,
      unrealizedPnlPercent: 0
    };
    setActiveTrades((prev) => [...prev, newTrade]);
    addToast(`📝 Paper position opened: ${amount} SOL notional in ${token.symbol}. Tracking P&L only — no funds moved.`, "success");
  };

  // Auto-trade condition watcher. When enabled and a configured condition is
  // met (e.g. bonding curve crosses threshold), this queues a PendingApproval
  // instead of executing anything. The user reviews and approves each one
  // individually from the Terminal tab, which is when (and only when) their
  // connected wallet extension would prompt them to actually sign.
  useEffect(() => {
    if (!autoTradeEngineEnabled || !wallet.connected) return;

    const scanTimer = setInterval(() => {
      newlyLaunched.forEach((token) => {
        const cleanAddr = token.address.toLowerCase();
        if (buyingAddressesRef.current.has(cleanAddr)) return;
        if (activeTrades.some(t => t.tokenAddress.toLowerCase() === cleanAddr)) return;
        if (pendingApprovals.some(p => p.tokenAddress.toLowerCase() === cleanAddr)) return;

        const meetsThreshold = snipeSettings.autoBuyBondingCurve &&
          token.bondingCurveProgress >= snipeSettings.bondingCurveThreshold;
        const meetsPotential = !snipeSettings.targetLowPotentialOnly ||
          parseFloat(token.potential) <= 5.0;

        if (meetsThreshold && meetsPotential) {
          buyingAddressesRef.current.add(cleanAddr);
          const approval: PendingApproval = {
            id: `appr-${Math.random().toString(36).substring(2, 9)}`,
            tokenAddress: token.address,
            tokenName: token.name,
            tokenSymbol: token.symbol,
            action: "buy",
            amountSol: snipeSettings.amountSol,
            reason: `Bonding curve crossed ${snipeSettings.bondingCurveThreshold}% threshold (now ${token.bondingCurveProgress}%)`,
            createdAt: Date.now()
          };
          setPendingApprovals(prev => [approval, ...prev]);
          addToast(`🔔 Auto-trade condition met for ${token.symbol} — approval needed in Terminal tab.`, "info");
        }
      });
    }, 3000);

    return () => clearInterval(scanTimer);
  }, [autoTradeEngineEnabled, wallet.connected, newlyLaunched, activeTrades, pendingApprovals, snipeSettings]);

  // Approving a pending entry opens the real wallet-adapter connect/send
  // flow conceptually — in this build it records the paper trade and asks
  // the person to execute the actual swap themselves (e.g. via Jupiter or
  // their wallet's built-in swap UI) before tracking it here. No signing
  // happens inside this app.
  const handleApprovePending = (approval: PendingApproval) => {
    const token = [...tokens, ...newlyLaunched].find(
      t => t.address.toLowerCase() === approval.tokenAddress.toLowerCase()
    );
    if (token) {
      handleBuySimulate(token as MemeCoin, approval.amountSol);
    }
    setPendingApprovals(prev => prev.filter(p => p.id !== approval.id));
    buyingAddressesRef.current.delete(approval.tokenAddress.toLowerCase());
    addToast(`✅ Approved. Paper position tracked — execute the real swap in your wallet if you want it live.`, "success");
  };

  const handleDismissPending = (approval: PendingApproval) => {
    setPendingApprovals(prev => prev.filter(p => p.id !== approval.id));
    buyingAddressesRef.current.delete(approval.tokenAddress.toLowerCase());
  };

  const filteredTokens = tokens.filter(t => {
    const matchesOrigin = originFilter === "all" || t.origin === originFilter;
    const matchesSearch =
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesOrigin && matchesSearch;
  });

  const sortedCompletedTrades = [...completedTrades].sort((a, b) => {
    let aVal: any = a[tradeSortField];
    let bVal: any = b[tradeSortField];
    if (aVal === undefined || bVal === undefined) return 0;
    if (typeof aVal === "string") {
      aVal = aVal.toLowerCase();
      bVal = (bVal as string).toLowerCase();
    }
    if (aVal < bVal) return tradeSortOrder === "asc" ? -1 : 1;
    if (aVal > bVal) return tradeSortOrder === "asc" ? 1 : -1;
    return 0;
  });

  const tradesPerPage = 10;
  const totalCompletedPages = Math.max(1, Math.ceil(sortedCompletedTrades.length / tradesPerPage));
  const indexOfLastTrade = tradePage * tradesPerPage;
  const indexOfFirstTrade = indexOfLastTrade - tradesPerPage;
  const paginatedCompletedTrades = sortedCompletedTrades.slice(indexOfFirstTrade, indexOfLastTrade);

  const handleToggleSort = (field: keyof CompletedTrade) => {
    if (tradeSortField === field) {
      setTradeSortOrder(prev => (prev === "asc" ? "desc" : "asc"));
    } else {
      setTradeSortField(field);
      setTradeSortOrder("desc");
    }
    setTradePage(1);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-lime-400 selection:text-black relative">
      <div className="absolute inset-0 cyber-grid opacity-10 pointer-events-none"></div>

      {/* TOAST NOTIFICATIONS */}
      <div className="fixed top-4 right-4 z-[60] space-y-2 w-full max-w-xs px-4 sm:px-0">
        <AnimatePresence>
          {notifications.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              className={`p-3 border-2 font-mono text-[11px] uppercase shadow-2xl ${
                n.type === "success" ? "bg-zinc-950 border-lime-400 text-lime-300" : "bg-zinc-950 border-zinc-700 text-zinc-300"
              }`}
            >
              {n.msg}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <WalletModal isOpen={isWalletOpen} onClose={() => setIsWalletOpen(false)} />

      {/* HEADER */}
      <header className="border-b-2 border-zinc-800 bg-zinc-950/95 sticky top-0 z-40 p-6">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="bg-lime-400 text-black px-4 py-1.5 font-black text-3xl tracking-tighter italic">X-RAY</div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-zinc-500 font-black tracking-widest text-[11px] uppercase">MEMECOIN INTELLIGENCE UNIT</span>
                <span className="bg-zinc-900 text-lime-400 border border-zinc-800 px-1.5 py-0.5 rounded-none text-[10px] font-mono font-black">V3.0</span>
              </div>
              <p className="text-[10px] text-zinc-400 font-mono tracking-widest uppercase mt-0.5">// SOLANA MEMECOIN ANALYSIS &amp; RUG-CHECK DASHBOARD</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 px-3 py-1.5 rounded-none">
              <span className={`w-2 h-2 ${demoMode ? "bg-lime-400 shadow-[0_0_8px_#a3e635]" : "bg-zinc-600"} rounded-full`}></span>
              <span className="text-[10px] uppercase font-black tracking-wider text-zinc-300">DEMO FEED</span>
              <button
                onClick={() => {
                  setDemoMode(!demoMode);
                  addToast(`Switched feed to ${!demoMode ? "Mock Datasets" : "Live DexScreener"}`, "info");
                }}
                className={`w-8 h-4 rounded-full relative transition-colors ${demoMode ? "bg-lime-400" : "bg-zinc-700"}`}
                title="Toggle Demo Mode"
              >
                <div className={`absolute top-0.5 w-3 h-3 rounded-full transition-all ${demoMode ? "right-0.5 bg-black" : "left-0.5 bg-white"}`}></div>
              </button>
            </div>

            {wallet.connected ? (
              <div className="flex items-center gap-3 bg-zinc-900 border-2 border-zinc-850 px-4 py-1.5 rounded-none font-mono">
                <div className="text-right">
                  <p className="text-[9px] text-zinc-500 font-black uppercase">WALLET BALANCE</p>
                  <p className="text-xs font-black text-lime-400 leading-tight mt-0.5">{wallet.balanceSol.toFixed(2)} SOL</p>
                </div>
                <div className="h-6 w-[1px] bg-zinc-800"></div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-white uppercase tracking-tight truncate max-w-[80px]">{wallet.publicKey}</span>
                    <button onClick={copyPublicKey} className="text-zinc-500 hover:text-white p-0.5">
                      {copiedAddr ? <Check className="w-3 h-3 text-lime-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                  <button onClick={() => disconnect()} className="text-[9px] text-rose-500 hover:text-rose-400 font-black uppercase block leading-none font-mono text-left tracking-wider italic">
                    [ DISCONNECT ]
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setIsWalletOpen(true)}
                className="bg-white text-black px-6 py-2.5 rounded-none font-black text-xs hover:bg-zinc-200 transition-colors uppercase tracking-widest italic border-2 border-white hover:border-zinc-200"
              >
                CONNECT WALLET
              </button>
            )}
          </div>
        </div>
      </header>

      {/* TICKER BAR */}
      <section className="bg-lime-500 text-black h-12 flex items-center px-6 overflow-hidden relative font-sans font-black uppercase tracking-tight">
        <div className="flex whitespace-nowrap gap-12 text-xs italic animate-scroll-left">
          <span className="flex items-center gap-2">DEXSCREENER FEED: ONLINE <Wifi className="w-4 h-4 shrink-0 text-black" /></span>
          <span className="flex items-center gap-2">SCANNING PUMP.FUN &amp; AXIOM POOLS <TrendingUp className="w-4 h-4 shrink-0 text-black" /></span>
          <span className="flex items-center gap-2 text-zinc-950 font-black">
            $SOL: ${marketData?.solPriceUsd ? marketData.solPriceUsd.toFixed(2) : "144.20"}
            <span className="text-[10px] bg-black/10 px-1 py-0.5 font-bold rounded-sm">
              {(marketData?.solPriceChange24h ?? -1.4) >= 0 ? "+" : ""}{(marketData?.solPriceChange24h ?? -1.4).toFixed(1)}%
            </span>
          </span>
          {marketData?.memecoins && marketData.memecoins.length > 0 ? (
            marketData.memecoins.map((t) => (
              <span key={t.address} className="flex items-center gap-2 text-zinc-900 font-extrabold uppercase">
                ${t.symbol}: ${t.priceUsd < 0.01 ? t.priceUsd.toFixed(6) : t.priceUsd.toFixed(3)}
                <span className={`text-[10px] px-1 py-0.5 rounded-sm ${t.priceChange24h >= 0 ? "bg-emerald-900/10 text-emerald-950" : "bg-rose-900/10 text-rose-950"}`}>
                  {t.priceChange24h >= 0 ? "+" : ""}{t.priceChange24h.toFixed(1)}%
                </span>
              </span>
            ))
          ) : (
            <>
              <span className="flex items-center gap-2 text-zinc-905">$WIF: $2.42 <span className="text-[10px] text-emerald-950 font-bold">(+4.2%)</span></span>
              <span className="flex items-center gap-2 text-zinc-905">$BONK: $0.000021 <span className="text-[10px] text-emerald-950 font-bold">(+11.8%)</span></span>
              <span className="flex items-center gap-2 text-zinc-905">$POPCAT: $1.15 <span className="text-[10px] text-rose-950 font-bold">(-2.1%)</span></span>
            </>
          )}
        </div>
      </section>

      {/* MAIN WORKSPACE */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-zinc-900 border-2 border-zinc-800 p-6 rounded-none">
          <div className="lg:col-span-8 flex flex-col justify-end space-y-4">
            <h1 className="text-6xl sm:text-7xl font-black italic leading-[0.8] tracking-widest text-white uppercase">
              LIVE<br />CALLS
            </h1>
            <div>
              <p className="text-lime-400 font-mono text-sm tracking-widest uppercase font-black animate-pulse">
                SCANNING SOLANA MEMECOIN POOLS...
              </p>
              <p className="text-zinc-500 text-[10px] font-mono uppercase font-black mt-2">
                Token data and rug-check scores from live DexScreener pairs.
              </p>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col justify-center items-center py-4 lg:border-l-2 lg:border-zinc-800">
            <div className="relative shrink-0">
              <div className="w-48 h-48 rounded-full border-[10px] border-zinc-950 flex flex-col items-center justify-center relative">
                <div className="absolute inset-0 rounded-full border-t-[10px] border-lime-400 rotate-[45deg]"></div>
                <div className="text-zinc-500 text-[9px] uppercase font-mono font-black tracking-widest mb-1">Avg Win Rate</div>
                <div className="text-4xl font-black italic leading-none text-white">{globalWinRate}<span className="text-xl not-italic text-lime-400">%</span></div>
                <div className="mt-2 text-[9px] font-mono text-zinc-400 uppercase tracking-tight">Across loaded tokens</div>
              </div>
            </div>
            <div className="text-center mt-3">
              <span className="text-[10px] font-mono text-zinc-500 italic">// AGGREGATE OF CURRENTLY LOADED TOKENS</span>
            </div>
          </div>
        </section>

        {/* TAB BAR */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-zinc-900 border-2 border-zinc-800 p-3 rounded-none shadow-2xl">
          <div className="flex flex-wrap gap-1.5">
            {([
              ["explore", "Explore", Layers],
              ["rug_checker", "Rug Checker", ShieldAlert],
              ["terminal", "Terminal", Activity],
              ["analytics", "Analytics", TrendingUp],
            ] as const).map(([key, label, Icon]) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`px-5 py-2.5 rounded-none text-xs font-mono font-black tracking-wider uppercase transition-all flex items-center gap-1.5 ${
                  tab === key ? "bg-lime-400 text-black italic" : "text-zinc-400 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
                {key === "terminal" && pendingApprovals.length > 0 && (
                  <span className="bg-rose-500 text-white text-[9px] px-1.5 rounded-full ml-1">{pendingApprovals.length}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {tab === "analytics" && (
          <AnalyticsPanel globalWinRate={globalWinRate} balanceSol={wallet.balanceSol} />
        )}

        {tab === "rug_checker" && (
          <RugChecker demoMode={demoMode} />
        )}

        {tab === "explore" && (
          <ExploreTab
            loading={loading}
            filteredTokens={filteredTokens}
            originFilter={originFilter}
            setOriginFilter={setOriginFilter}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            wallet={wallet}
            onBuySimulate={handleBuySimulate}
            priceAlerts={priceAlerts}
            onAddPriceAlert={handleAddPriceAlert}
            onRemovePriceAlert={handleRemovePriceAlert}
            onRefresh={() => loadData(demoMode)}
          />
        )}

        {tab === "terminal" && (
          <TerminalTab
            terminalSubTab={terminalSubTab}
            setTerminalSubTab={setTerminalSubTab}
            txLogs={txLogs}
            activeTrades={activeTrades}
            onClosePaperPosition={closePaperPosition}
            paginatedCompletedTrades={paginatedCompletedTrades}
            tradeSortField={tradeSortField}
            tradeSortOrder={tradeSortOrder}
            onToggleSort={handleToggleSort}
            tradePage={tradePage}
            setTradePage={setTradePage}
            totalCompletedPages={totalCompletedPages}
            pendingApprovals={pendingApprovals}
            onApprovePending={handleApprovePending}
            onDismissPending={handleDismissPending}
            autoTradeEngineEnabled={autoTradeEngineEnabled}
            setAutoTradeEngineEnabled={setAutoTradeEngineEnabled}
            snipeSettings={snipeSettings}
            setSnipeSettings={setSnipeSettings}
            walletConnected={wallet.connected}
          />
        )}
      </main>

      <footer className="border-t-2 border-zinc-900 py-6 text-center">
        <p className="text-[10px] text-zinc-600 font-mono uppercase tracking-widest">
          For informational purposes only. Not financial advice. Memecoins are highly volatile and high-risk.
        </p>
      </footer>
    </div>
  );
}


