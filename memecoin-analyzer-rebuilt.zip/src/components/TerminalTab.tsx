import React from "react";
import {
  Activity,
  ShieldAlert,
  ThumbsUp,
  X,
  Play,
  Square,
  Clock,
} from "lucide-react";
import { SimulationTx, ActiveTrade, CompletedTrade, AutoTradeSettings, PendingApproval } from "../types";

interface TerminalTabProps {
  terminalSubTab: "logs" | "trades" | "approvals";
  setTerminalSubTab: (v: "logs" | "trades" | "approvals") => void;
  txLogs: SimulationTx[];
  activeTrades: ActiveTrade[];
  onClosePaperPosition: (trade: ActiveTrade, isAuto: boolean, reason: string) => void;
  paginatedCompletedTrades: CompletedTrade[];
  tradeSortField: keyof CompletedTrade;
  tradeSortOrder: "asc" | "desc";
  onToggleSort: (field: keyof CompletedTrade) => void;
  tradePage: number;
  setTradePage: (v: number) => void;
  totalCompletedPages: number;
  pendingApprovals: PendingApproval[];
  onApprovePending: (a: PendingApproval) => void;
  onDismissPending: (a: PendingApproval) => void;
  autoTradeEngineEnabled: boolean;
  setAutoTradeEngineEnabled: (v: boolean) => void;
  snipeSettings: AutoTradeSettings;
  setSnipeSettings: React.Dispatch<React.SetStateAction<AutoTradeSettings>>;
  walletConnected: boolean;
}

export default function TerminalTab({
  terminalSubTab,
  setTerminalSubTab,
  txLogs,
  activeTrades,
  onClosePaperPosition,
  paginatedCompletedTrades,
  tradeSortField,
  tradeSortOrder,
  onToggleSort,
  tradePage,
  setTradePage,
  totalCompletedPages,
  pendingApprovals,
  onApprovePending,
  onDismissPending,
  autoTradeEngineEnabled,
  setAutoTradeEngineEnabled,
  snipeSettings,
  setSnipeSettings,
  walletConnected,
}: TerminalTabProps) {
  const sortArrow = (field: keyof CompletedTrade) =>
    tradeSortField === field ? (tradeSortOrder === "asc" ? "▲" : "▼") : "";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* LEFT: Logs / Trades / Approvals */}
      <div className="lg:col-span-8 bg-zinc-950 border-2 border-zinc-800 rounded-none p-6 shadow-2xl space-y-6">
        <div className="pb-4 border-b-2 border-zinc-800">
          <h2 className="text-xl font-mono font-black text-white uppercase italic tracking-tighter">TERMINAL</h2>
          <p className="text-xs text-zinc-500 font-sans uppercase tracking-widest">
            Paper-trade ledger and pending approvals. No real funds are moved by this app.
          </p>
        </div>

        <div className="flex border-b border-zinc-850 gap-1 flex-wrap">
          <button
            type="button"
            onClick={() => setTerminalSubTab("logs")}
            className={`px-4 py-2.5 font-mono text-xs font-black uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              terminalSubTab === "logs" ? "border-lime-400 text-lime-400 bg-zinc-900/50" : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            📡 Logs
            <span className="text-[9px] bg-zinc-850 text-zinc-400 px-1 inline-block rounded-sm">{txLogs.length}</span>
          </button>
          <button
            type="button"
            onClick={() => { setTerminalSubTab("trades"); setTradePage(1); }}
            className={`px-4 py-2.5 font-mono text-xs font-black uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              terminalSubTab === "trades" ? "border-lime-400 text-lime-400 bg-zinc-900/50" : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            📜 Trade History
            <span className="text-[9px] bg-zinc-850 text-zinc-400 px-1 inline-block rounded-sm">{paginatedCompletedTrades.length}</span>
          </button>
          <button
            type="button"
            onClick={() => setTerminalSubTab("approvals")}
            className={`px-4 py-2.5 font-mono text-xs font-black uppercase tracking-wider transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              terminalSubTab === "approvals" ? "border-lime-400 text-lime-400 bg-zinc-900/50" : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            ⏳ Approvals Needed
            {pendingApprovals.length > 0 && (
              <span className="text-[9px] bg-rose-500 text-white px-1.5 inline-block rounded-full">{pendingApprovals.length}</span>
            )}
          </button>
        </div>

        {terminalSubTab === "logs" && (
          <div className="bg-zinc-900 border-2 border-zinc-800 rounded-none overflow-hidden font-mono text-xs">
            <div className="p-3 bg-zinc-950 border-b border-zinc-850 flex justify-between items-center text-[10px] text-zinc-500 font-black uppercase">
              <span>PAPER-TRADE ACTIVITY LOG</span>
              <span>ENTRIES: {txLogs.length}</span>
            </div>
            <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
              {txLogs.length === 0 ? (
                <div className="text-center py-10 text-zinc-600 font-black">
                  <p>// NO ACTIVITY YET</p>
                  <p className="text-[10px] mt-1.5 uppercase font-mono tracking-wider">
                    Connect a wallet and click "Snipe" on a token in Explore to open a paper position.
                  </p>
                </div>
              ) : (
                txLogs.map((log) => (
                  <div key={log.id} className="p-4 bg-zinc-950 border border-zinc-850 rounded-none flex flex-col sm:flex-row justify-between gap-3 text-zinc-300 font-mono uppercase">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-black tracking-widest px-2 py-0.5 bg-zinc-850 text-white">{log.type}</span>
                        <span className="font-black text-white italic tracking-tight">{log.tokenName} ({log.tokenSymbol})</span>
                      </div>
                      <p className="text-[10px] text-zinc-500 font-light">TX: <span className="text-zinc-450">{log.id}</span></p>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-x-4 shrink-0">
                      <div className="text-right">
                        <p className="text-lime-400 font-black">{log.type.includes("sell") ? "+" : "-"}{log.amountSol.toFixed(2)} SOL</p>
                        <p className="text-[9px] text-zinc-500">{new Date(log.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {terminalSubTab === "trades" && (
          <div className="bg-zinc-900 border-2 border-zinc-800 rounded-none overflow-hidden font-mono text-xs p-4 space-y-4">
            {paginatedCompletedTrades.length === 0 ? (
              <div className="text-center py-12 text-zinc-600 font-black font-mono">
                <p>// NO CLOSED PAPER TRADES YET</p>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto border border-zinc-800">
                  <table className="w-full text-left border-collapse table-auto">
                    <thead>
                      <tr className="bg-zinc-950 border-b border-zinc-800 text-[10px] text-zinc-400 font-extrabold uppercase tracking-wider">
                        <th className="py-2.5 px-3 text-left">
                          <button onClick={() => onToggleSort("symbol")} className="hover:text-white">Token {sortArrow("symbol")}</button>
                        </th>
                        <th className="py-2.5 px-3 text-right">
                          <button onClick={() => onToggleSort("pnlSol")} className="hover:text-white">P&amp;L {sortArrow("pnlSol")}</button>
                        </th>
                        <th className="py-2.5 px-3 text-center">
                          <button onClick={() => onToggleSort("timestamp")} className="hover:text-white">Date {sortArrow("timestamp")}</button>
                        </th>
                        <th className="py-2.5 px-3 text-right hidden md:table-cell">Trigger</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono text-[11px] text-zinc-300">
                      {paginatedCompletedTrades.map((t) => {
                        const isWin = t.pnlSol >= 0;
                        return (
                          <tr key={t.id} className="hover:bg-zinc-800/40 uppercase">
                            <td className="py-2.5 px-3 font-black">
                              <span className="text-white block italic">{t.symbol}</span>
                              <span className="text-[9px] text-zinc-500 block max-w-[120px] truncate">{t.tokenName}</span>
                            </td>
                            <td className={`py-2.5 px-3 text-right font-black ${isWin ? "text-lime-400" : "text-rose-450"}`}>
                              <span className="block">{isWin ? "+" : ""}{t.pnlSol.toFixed(4)} SOL</span>
                              <span className="block text-[9px] font-normal">{isWin ? "+" : ""}{t.pnlPercent.toFixed(1)}%</span>
                            </td>
                            <td className="py-2.5 px-3 text-center text-[10px] text-zinc-400">
                              {new Date(t.timestamp).toLocaleDateString()}
                            </td>
                            <td className="py-2.5 px-3 text-right hidden md:table-cell text-[10px] text-zinc-400">
                              <span className={`px-1.5 py-0.5 text-[9px] font-extrabold uppercase inline-block mb-1 ${t.isAuto ? "bg-cyan-950/45 text-cyan-400" : "bg-zinc-850 text-zinc-400"}`}>
                                {t.isAuto ? "🤖 Bot" : "👤 Manual"}
                              </span>
                              <span className="block text-[9px] font-light lowercase text-zinc-500 italic max-w-[150px] truncate" title={t.reason}>{t.reason}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <span className="text-[10px] text-zinc-500 font-black uppercase">PAGE {tradePage} OF {totalCompletedPages}</span>
                  <div className="flex gap-2">
                    <button disabled={tradePage === 1} onClick={() => setTradePage(tradePage - 1)} className="px-3 py-1 border border-zinc-800 text-[10px] font-mono uppercase disabled:opacity-30">PREV</button>
                    <button disabled={tradePage === totalCompletedPages} onClick={() => setTradePage(tradePage + 1)} className="px-3 py-1 border border-zinc-800 text-[10px] font-mono uppercase disabled:opacity-30">NEXT</button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {terminalSubTab === "approvals" && (
          <div className="space-y-3">
            <div className="bg-zinc-900/60 border border-zinc-800 p-3 text-[10px] font-mono text-zinc-400 uppercase leading-relaxed">
              When the auto-trade watcher detects a condition you configured, it lists it here instead of
              acting on its own. Approving opens a paper position to track; it does not sign or send anything.
              To actually execute a trade, use your wallet's own swap feature (e.g. Phantom's built-in swap, or Jupiter).
            </div>
            {pendingApprovals.length === 0 ? (
              <div className="text-center py-12 text-zinc-600 font-black font-mono border-2 border-zinc-800 bg-zinc-900">
                <p>// NO PENDING APPROVALS</p>
              </div>
            ) : (
              pendingApprovals.map((a) => (
                <div key={a.id} className="p-4 border-2 border-amber-900/40 bg-amber-950/10 flex flex-col sm:flex-row justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span className="font-mono text-xs font-black text-white uppercase italic">{a.action.toUpperCase()} {a.tokenSymbol}</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 font-mono uppercase">{a.reason}</p>
                    <p className="text-[10px] text-amber-400 font-mono">{a.amountSol} SOL</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onApprovePending(a)}
                      className="px-3 py-1.5 bg-lime-400 hover:bg-lime-300 text-black text-[10px] font-mono font-black uppercase flex items-center gap-1"
                    >
                      <ThumbsUp className="w-3 h-3" /> Approve
                    </button>
                    <button
                      onClick={() => onDismissPending(a)}
                      className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:text-white text-[10px] font-mono font-black uppercase flex items-center gap-1"
                    >
                      <X className="w-3 h-3" /> Dismiss
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* RIGHT: Active paper positions + auto-trade settings */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-zinc-950 border-2 border-zinc-800 p-5 space-y-3">
          <h3 className="font-mono text-sm font-black uppercase italic text-white flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-lime-400" /> Open Paper Positions
          </h3>
          {activeTrades.length === 0 ? (
            <p className="text-[10px] text-zinc-600 font-mono uppercase">No open positions.</p>
          ) : (
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {activeTrades.map((t) => (
                <div key={t.id} className="p-3 bg-zinc-900 border border-zinc-850 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-xs font-black text-white italic">{t.symbol}</span>
                    <span className={`font-mono text-xs font-black ${t.unrealizedPnlPercent >= 0 ? "text-lime-400" : "text-rose-450"}`}>
                      {t.unrealizedPnlPercent >= 0 ? "+" : ""}{t.unrealizedPnlPercent}%
                    </span>
                  </div>
                  <div className="text-[9px] text-zinc-500 font-mono uppercase">{t.amountSol} SOL notional</div>
                  <button
                    onClick={() => onClosePaperPosition(t, false, "Manual paper close")}
                    className="w-full text-[9px] font-mono font-black uppercase py-1 border border-zinc-800 text-zinc-400 hover:text-white hover:border-lime-400"
                  >
                    Close Paper Position
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-zinc-950 border-2 border-zinc-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-mono text-sm font-black uppercase italic text-white">Auto-Trade Watcher</h3>
            <button
              onClick={() => setAutoTradeEngineEnabled(!autoTradeEngineEnabled)}
              disabled={!walletConnected}
              className={`px-3 py-1 text-[10px] font-mono font-black uppercase flex items-center gap-1 disabled:opacity-40 ${
                autoTradeEngineEnabled ? "bg-lime-400 text-black" : "bg-zinc-900 text-zinc-400 border border-zinc-800"
              }`}
            >
              {autoTradeEngineEnabled ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {autoTradeEngineEnabled ? "WATCHING" : "OFF"}
            </button>
          </div>
          {!walletConnected && (
            <p className="text-[9px] text-amber-400 font-mono uppercase flex items-center gap-1">
              <ShieldAlert className="w-3 h-3" /> Connect a wallet to enable the watcher.
            </p>
          )}
          <p className="text-[9px] text-zinc-500 font-mono uppercase leading-relaxed">
            This watches conditions only. It queues an approval — it never signs or sends a transaction by itself.
          </p>

          <div className="space-y-3 pt-2 border-t border-zinc-900">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-zinc-400 uppercase">Watch bonding curve</span>
              <button
                onClick={() => setSnipeSettings(prev => ({ ...prev, autoBuyBondingCurve: !prev.autoBuyBondingCurve }))}
                className={`px-2 py-0.5 text-[9px] font-mono font-black uppercase ${
                  snipeSettings.autoBuyBondingCurve ? "bg-lime-400 text-black" : "bg-zinc-850 text-zinc-500"
                }`}
              >
                {snipeSettings.autoBuyBondingCurve ? "ON" : "OFF"}
              </button>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[9px] font-mono text-zinc-500 uppercase">
                <span>Threshold</span>
                <span className="text-lime-400">{snipeSettings.bondingCurveThreshold}%</span>
              </div>
              <input
                type="range" min={10} max={99}
                value={snipeSettings.bondingCurveThreshold}
                onChange={(e) => setSnipeSettings(prev => ({ ...prev, bondingCurveThreshold: parseInt(e.target.value) }))}
                className="w-full accent-lime-400"
              />
            </div>

            <div className="space-y-1">
              <span className="text-[9px] font-mono text-zinc-500 uppercase">Amount per trade</span>
              <div className="flex gap-1.5">
                {[0.1, 0.2, 0.5, 1.0].map((val) => (
                  <button
                    key={val}
                    onClick={() => setSnipeSettings(prev => ({ ...prev, amountSol: val }))}
                    className={`flex-1 py-1 text-[9px] font-mono font-black border ${
                      snipeSettings.amountSol === val ? "bg-lime-400 text-black border-lime-400" : "bg-zinc-900 text-zinc-400 border-zinc-800"
                    }`}
                  >
                    {val}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[9px] font-mono text-zinc-500 uppercase">
                <span>Take profit</span>
                <span className="text-lime-400 font-black">+{snipeSettings.takeProfitPercent}%</span>
              </div>
              <input
                type="range" min={10} max={300}
                value={snipeSettings.takeProfitPercent}
                onChange={(e) => setSnipeSettings(prev => ({ ...prev, takeProfitPercent: parseInt(e.target.value) }))}
                className="w-full accent-lime-400"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[9px] font-mono text-zinc-500 uppercase">
                <span>Stop loss</span>
                <span className="text-rose-500 font-black">-{snipeSettings.stopLossPercent}%</span>
              </div>
              <input
                type="range" min={5} max={90}
                value={snipeSettings.stopLossPercent}
                onChange={(e) => setSnipeSettings(prev => ({ ...prev, stopLossPercent: parseInt(e.target.value) }))}
                className="w-full accent-rose-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-zinc-400 uppercase">Trailing stop</span>
              <button
                onClick={() => setSnipeSettings(s => ({ ...s, trailingStopPercent: s.trailingStopPercent === null ? 10 : null }))}
                className={`px-2 py-0.5 text-[9px] font-mono font-black uppercase border ${
                  snipeSettings.trailingStopPercent !== null ? "bg-lime-400 text-black border-lime-400" : "bg-zinc-900 text-zinc-500 border-zinc-800"
                }`}
              >
                {snipeSettings.trailingStopPercent !== null ? "ON" : "OFF"}
              </button>
            </div>
            {snipeSettings.trailingStopPercent !== null && (
              <input
                type="range" min={2} max={50}
                value={snipeSettings.trailingStopPercent}
                onChange={(e) => setSnipeSettings(prev => ({ ...prev, trailingStopPercent: parseInt(e.target.value) }))}
                className="w-full accent-purple-400"
              />
            )}

            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-zinc-400 uppercase">2x–5x targets only</span>
              <button
                onClick={() => setSnipeSettings(prev => ({ ...prev, targetLowPotentialOnly: !prev.targetLowPotentialOnly }))}
                className={`px-2 py-0.5 text-[9px] font-mono font-black uppercase ${
                  snipeSettings.targetLowPotentialOnly ? "bg-lime-400 text-black" : "bg-zinc-850 text-zinc-500"
                }`}
              >
                {snipeSettings.targetLowPotentialOnly ? "YES" : "NO"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
