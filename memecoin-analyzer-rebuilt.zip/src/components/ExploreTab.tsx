import React from "react";
import { motion } from "motion/react";
import { Search, RotateCw, Bell, Copy, Trash2 } from "lucide-react";
import { MemeCoin, WalletState, PriceAlert } from "../types";
import TokenCard from "./TokenCard";

interface NewlyLaunchedCoin extends MemeCoin {
  bondingCurveProgress: number;
}

interface ExploreTabProps {
  loading: boolean;
  filteredTokens: MemeCoin[];
  originFilter: "all" | "axiom" | "pump.fun";
  setOriginFilter: (v: "all" | "axiom" | "pump.fun") => void;
  searchQuery: string;
  setSearchQuery: (v: string) => void;
  wallet: WalletState;
  onBuySimulate: (token: MemeCoin, amount: number) => void;
  priceAlerts: PriceAlert[];
  onAddPriceAlert: (token: MemeCoin, targetPrice: number, condition: "above" | "below") => void;
  onRemovePriceAlert: (id: string) => void;
  onRefresh: () => void;
}

export default function ExploreTab({
  loading,
  filteredTokens,
  originFilter,
  setOriginFilter,
  searchQuery,
  setSearchQuery,
  wallet,
  onBuySimulate,
  priceAlerts,
  onAddPriceAlert,
  onRemovePriceAlert,
  onRefresh,
}: ExploreTabProps) {
  return (
    <div className="space-y-8 transition-all duration-300">
      {/* ACTIVE ALERTS SUMMARY */}
      {priceAlerts.length > 0 && (
        <div className="border-2 border-zinc-800 bg-zinc-950 p-5 space-y-3">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-mono font-black tracking-tight uppercase italic text-white">
                {priceAlerts.filter(a => !a.triggered).length} ALERT{priceAlerts.filter(a => !a.triggered).length === 1 ? "" : "S"} ACTIVE
              </h2>
            </div>
            <button
              onClick={() => priceAlerts.forEach(a => onRemovePriceAlert(a.id))}
              className="text-[10px] text-rose-400 border border-rose-900/40 bg-rose-950/20 hover:bg-rose-500 hover:text-black px-3 py-1 font-mono uppercase tracking-tight transition-all cursor-pointer font-black"
            >
              CLEAR ALL
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {priceAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`flex items-center gap-2 px-2.5 py-1.5 border text-[10px] font-mono uppercase ${
                  alert.triggered ? "border-zinc-900 bg-zinc-900/40 text-zinc-500 line-through" : "border-zinc-800 bg-zinc-900/60 text-white"
                }`}
              >
                <span className="font-bold">{alert.tokenSymbol}</span>
                <span>{alert.condition === "above" ? "↑" : "↓"} ${alert.targetPriceUsd < 0.0001 ? alert.targetPriceUsd.toFixed(8) : alert.targetPriceUsd.toFixed(4)}</span>
                <button onClick={() => onRemovePriceAlert(alert.id)} className="text-zinc-500 hover:text-rose-500">
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SEARCH / FILTER BAR */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center bg-zinc-900 border-2 border-zinc-800 p-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="SEARCH BY NAME, SYMBOL, OR CONTRACT ADDRESS"
            className="w-full pl-10 pr-3 py-2.5 bg-zinc-950 border-2 border-zinc-800 focus:border-lime-400 text-white text-xs font-mono placeholder:text-zinc-600 outline-none uppercase"
          />
        </div>
        <div className="flex bg-zinc-950 border-2 border-zinc-800 font-mono text-[10px] uppercase font-black">
          {(["all", "axiom", "pump.fun"] as const).map((o) => (
            <button
              key={o}
              onClick={() => setOriginFilter(o)}
              className={`px-3 py-2.5 ${originFilter === o ? "bg-lime-400 text-black" : "text-zinc-400 hover:text-white"}`}
            >
              {o}
            </button>
          ))}
        </div>
        <button
          onClick={onRefresh}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 border-2 border-zinc-800 hover:border-lime-400 bg-zinc-950 font-mono text-[10px] font-black uppercase text-lime-400"
        >
          <RotateCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          REFRESH
        </button>
      </div>

      {/* TOKEN GRID */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-80 bg-zinc-900 border-2 border-zinc-850 animate-pulse" />
          ))}
        </div>
      ) : filteredTokens.length === 0 ? (
        <div className="text-center py-16 border-2 border-zinc-800 bg-zinc-950">
          <p className="text-zinc-500 font-mono text-xs uppercase">No tokens match your filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTokens.map((token) => (
            <TokenCard
              key={token.address}
              token={token}
              walletState={wallet}
              onBuySimulate={onBuySimulate}
              priceAlerts={priceAlerts.filter(a => a.tokenAddress.toLowerCase() === token.address.toLowerCase())}
              onAddPriceAlert={onAddPriceAlert}
              onRemovePriceAlert={onRemovePriceAlert}
            />
          ))}
        </div>
      )}
    </div>
  );
}
