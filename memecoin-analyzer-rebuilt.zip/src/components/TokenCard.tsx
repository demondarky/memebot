import React, { useState, useEffect, useRef } from "react";
import { MemeCoin, WalletState, PriceAlert } from "../types";
import { Copy, Check, TrendingUp, TrendingDown, ShieldCheck, ShieldAlert, Award, ExternalLink, Zap, Coins, Bell, BellRing, Trash2, X } from "lucide-react";
import { motion } from "motion/react";

interface TokenCardProps {
  key?: string;
  token: MemeCoin;
  walletState: WalletState;
  onBuySimulate: (token: MemeCoin, amount: number) => void;
  priceAlerts: PriceAlert[];
  onAddPriceAlert: (token: MemeCoin, targetPrice: number, condition: "above" | "below") => void;
  onRemovePriceAlert: (id: string) => void;
}

export default function TokenCard({
  token,
  walletState,
  onBuySimulate,
  priceAlerts,
  onAddPriceAlert,
  onRemovePriceAlert
}: TokenCardProps) {
  const [copied, setCopied] = useState(false);
  const [buyAmount, setBuyAmount] = useState(0.1);
  const [buying, setBuying] = useState(false);
  const [showAlertForm, setShowAlertForm] = useState(false);
  const [targetAlertPrice, setTargetAlertPrice] = useState("");
  const [alertCondition, setAlertCondition] = useState<"above" | "below">("above");
  const [showRugDetails, setShowRugDetails] = useState(false);
  const [flash, setFlash] = useState<"up" | "down" | null>(null);
  const prevPriceRef = useRef<number>(token.priceUsd);

  useEffect(() => {
    if (token.priceUsd !== prevPriceRef.current) {
      if (token.priceUsd > prevPriceRef.current) {
        setFlash("up");
      } else if (token.priceUsd < prevPriceRef.current) {
        setFlash("down");
      }
      prevPriceRef.current = token.priceUsd;
      const timer = setTimeout(() => {
        setFlash(null);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [token.priceUsd]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(token.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const executeSimulatedBuy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!walletState.connected) return;
    if (walletState.balanceSol < buyAmount) {
      alert("Insufficient SOL budget for this transactional simulation!");
      return;
    }

    setBuying(true);
    await new Promise((resolve) => setTimeout(resolve, 800)); // Realistic block confirmation time
    onBuySimulate(token, buyAmount);
    setBuying(false);
  };

  const priceFormatted = token.priceUsd < 0.00001
    ? `$${token.priceUsd.toFixed(8)}`
    : `$${token.priceUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 5 })}`;

  const volFormatted = token.volume24h >= 1000000
    ? `$${(token.volume24h / 1000000).toFixed(2)}M`
    : `$${(token.volume24h / 1000).toFixed(1)}k`;

  const mcapFormatted = token.marketCap >= 1000000
    ? `$${(token.marketCap / 1000000).toFixed(2)}M`
    : `$${(token.marketCap / 1000).toFixed(1)}k`;

  const liqFormatted = token.liquidityUsd >= 1000000
    ? `$${(token.liquidityUsd / 1000000).toFixed(2)}M`
    : `$${(token.liquidityUsd / 1000).toFixed(1)}k`;

  // Dynamic aesthetic based on 2x-20x multipliers
  const parsedMult = parseFloat(token.potential) || 2.0;
  const isHighPotential = parsedMult >= 8.0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`h-full border-2 bg-zinc-950 hover:bg-zinc-900/40 border-zinc-800 rounded-none p-5 hover:border-lime-400 transition-all shadow-xl group flex flex-col justify-between relative overflow-hidden`}
    >
      <div>
        {/* Token Origin Flag & Potential Badge */}
        <div className="flex justify-between items-center mb-3">
          <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-none border uppercase flex items-center gap-1 ${
            token.origin === "axiom" 
              ? "bg-zinc-900 text-lime-400 border-zinc-800" 
              : "bg-zinc-900 text-white border-zinc-800"
          }`}>
            <span className={`w-1.5 h-1.5 ${token.origin === "axiom" ? "bg-lime-400 animate-pulse" : "bg-white"}`}></span>
            {token.origin}
          </span>

          <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-none border flex items-center gap-1 uppercase italic ${
            isHighPotential 
              ? "bg-lime-400 text-black border-lime-400" 
              : "bg-zinc-900 text-zinc-300 border-zinc-800"
          }`}>
            <Award className="w-3 h-3" />
            {token.potential} HIGH-X
          </span>
        </div>

        {/* Name / Logo representation */}
        <div className="flex items-center gap-3 mb-4">
          <img
            src={token.imageUrl}
            alt={token.name}
            className="w-11 h-11 rounded-none object-cover border-2 border-zinc-800 shadow-inner shrink-0"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=150&auto=format&fit=crop&q=80";
            }}
          />
          <div className="overflow-hidden">
            <h3 className="font-mono text-sm font-black text-white flex items-center gap-1 uppercase italic tracking-tighter">
              <span className="truncate">{token.name}</span>
              <span className="text-[10px] text-zinc-500 font-bold not-italic">{token.symbol}</span>
            </h3>

            {/* Copyable Contract Address */}
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10.5px] font-mono text-zinc-400 bg-zinc-900 border border-zinc-850 px-2 py-0.5 rounded-none truncate max-w-[130px] uppercase tracking-wider">{token.address}</span>
              <button
                onClick={handleCopy}
                type="button"
                className="text-zinc-400 hover:text-lime-400 hover:bg-zinc-800/80 border border-zinc-800 transition-all p-1 flex items-center justify-center cursor-pointer"
                title="Copy Token CA"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-lime-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Price & Probability Section */}
        <div className="grid grid-cols-2 gap-2 p-3 bg-zinc-900/60 border-2 border-zinc-850 rounded-none mb-3">
          <div>
            <span className="text-[9px] font-mono text-zinc-500 block uppercase font-bold tracking-tight">PRICE USD</span>
            <span className={`font-mono text-[13px] font-black transition-all duration-350 px-1 py-0.5 rounded-sm block ${
              flash === "up" 
                ? "bg-emerald-950/50 text-emerald-450 border border-emerald-500/30 shadow-[0_0_10px_rgba(16,185,129,0.3)] glow-green" 
                : flash === "down" 
                ? "bg-rose-950/50 text-rose-450 border border-rose-500/30 shadow-[0_0_10px_rgba(244,63,94,0.3)] glow-orange" 
                : "text-white"
            }`}>
              {priceFormatted}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[9px] font-mono text-zinc-500 block uppercase font-bold tracking-tight">WIN RATE</span>
            <span className="font-mono text-[13px] font-black text-lime-400">{token.winRate}%</span>
          </div>
        </div>

        {/* Custom Price Target Alert Section */}
        <div className="mb-4 border border-zinc-850 bg-zinc-950/60 p-2.5 font-mono text-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[9.5px] text-zinc-400 font-extrabold uppercase tracking-wider flex items-center gap-1">
              <Bell className="w-3.5 h-3.5 text-lime-400" /> TARGET WATCHER
            </span>
            <button
              type="button"
              onClick={() => {
                setShowAlertForm(!showAlertForm);
                setTargetAlertPrice(token.priceUsd.toString());
              }}
              className="text-[9px] bg-zinc-900 border border-zinc-800 text-lime-450 text-lime-400 hover:text-black hover:bg-lime-400 px-2 py-0.5 font-black uppercase transition-all duration-150 cursor-pointer"
            >
              {showAlertForm ? "Hide" : "+ Set Alert"}
            </button>
          </div>

          {showAlertForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-2 mt-2 pt-2 border-t border-zinc-900"
            >
              <div className="flex gap-2 items-center">
                <span className="text-[9px] text-zinc-400 font-bold uppercase shrink-0">CONDITION:</span>
                <div className="grid grid-cols-2 gap-1 flex-1">
                  <button
                    type="button"
                    onClick={() => setAlertCondition("above")}
                    className={`py-1 text-[9px] font-black uppercase border transition-all cursor-pointer ${
                      alertCondition === "above"
                        ? "bg-lime-400 text-black border-lime-400"
                        : "bg-zinc-900 text-zinc-400 border-zinc-800"
                    }`}
                  >
                    ABOVE ↑
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertCondition("below")}
                    className={`py-1 text-[9px] font-black uppercase border transition-all cursor-pointer ${
                      alertCondition === "below"
                        ? "bg-lime-400 text-black border-lime-400"
                        : "bg-zinc-900 text-zinc-400 border-zinc-800"
                    }`}
                  >
                    BELOW ↓
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-zinc-500 text-[10px] font-black">$</span>
                  <input
                    type="text"
                    value={targetAlertPrice}
                    onChange={(e) => setTargetAlertPrice(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-zinc-900 border border-zinc-800 text-white pl-5.5 pr-2 py-1.5 font-mono text-[11px] outline-none focus:border-lime-400"
                  />
                </div>
              </div>

              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    const priceVal = parseFloat(targetAlertPrice);
                    if (isNaN(priceVal) || priceVal <= 0) {
                      alert("Please specify a valid alert target price!");
                      return;
                    }
                    onAddPriceAlert(token, priceVal, alertCondition);
                    setShowAlertForm(false);
                  }}
                  className="w-full bg-lime-400 hover:bg-lime-500 text-black py-1.5 font-black text-[9px] uppercase tracking-wider transition-all cursor-pointer"
                >
                  ARM WATCHER ⚡
                </button>
              </div>
            </motion.div>
          )}

          {/* Active watchlist of price target alerts */}
          {priceAlerts && priceAlerts.length > 0 ? (
            <div className="space-y-1.5 mt-2 pt-2 border-t border-zinc-900">
              {priceAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`flex items-center justify-between px-2 py-1.5 border font-mono text-[10px] ${
                    alert.triggered
                      ? "bg-zinc-900/40 border-zinc-900 opacity-40 text-zinc-500 line-through"
                      : "bg-zinc-900/20 border-lime-500/20 text-white"
                  }`}
                >
                  <span className="flex items-center gap-1 font-bold">
                    {alert.triggered ? "✓ " : "⏰ "}
                    {alert.condition === "above" ? "ABOVE" : "BELOW"} $
                    {alert.targetPriceUsd < 0.0001
                      ? alert.targetPriceUsd.toFixed(8)
                      : alert.targetPriceUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 5 })}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemovePriceAlert(alert.id)}
                    className="text-zinc-500 hover:text-rose-500 p-0.5 cursor-pointer"
                    title="Remove alert"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            !showAlertForm && (
              <p className="text-[9px] text-zinc-500 uppercase tracking-widest pt-1 italic">
                // NO ALERTS ARMED ON THIS TOKEN
              </p>
            )
          )}
        </div>

        {/* On-Chain Vital Statistics */}
        <div className="space-y-2 mb-4 font-mono text-xs uppercase">
          <div className="flex justify-between items-center">
            <span className="text-zinc-500 font-bold">24H PRICE STATS:</span>
            <span className={`font-black flex items-center gap-0.5 ${
              token.priceChange24h >= 0 ? "text-lime-400" : "text-rose-500"
            }`}>
              {token.priceChange24h >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {token.priceChange24h >= 0 ? "+" : ""}{token.priceChange24h.toFixed(1)}%
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-zinc-500 font-bold">24H VOLUME STREAM:</span>
            <span className="font-black text-white">{volFormatted}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-zinc-500 font-bold">LIQUIDITY DEPTH:</span>
            <span className="font-black text-white">{liqFormatted}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-zinc-500 font-bold">VALUATION (MCAP):</span>
            <span className="font-black text-white">{mcapFormatted}</span>
          </div>

          <div
            onClick={() => setShowRugDetails(!showRugDetails)}
            className="flex justify-between items-center border-t-2 border-zinc-800/80 pt-2 mt-2 cursor-pointer group/rug"
            title="Click to expand automated security contract audit"
          >
            <span className="text-zinc-400 font-extrabold flex items-center gap-1 group-hover/rug:text-white transition-colors">
              RUG CHECK SCORE <span className="text-[9px] text-zinc-500 font-normal">({showRugDetails ? "HIDE" : "SHOW AUDIT"})</span>:
            </span>
            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-none border flex items-center gap-1 transition-all ${
              token.rugScore >= 80 
                ? "bg-zinc-900 text-lime-400 border-zinc-800 group-hover/rug:border-lime-400" 
                : token.rugScore >= 50
                  ? "bg-zinc-900 text-amber-400 border-zinc-800 group-hover/rug:border-amber-400"
                  : "bg-rose-955/40 text-rose-500 border-rose-900/40 group-hover/rug:border-rose-450"
            }`}>
              {token.rugScore >= 85 ? (
                <ShieldCheck className="w-3.5 h-3.5 text-lime-400" />
              ) : (
                <ShieldAlert className="w-3.5 h-3.5" />
              )}
              {token.rugScore}/100
            </span>
          </div>

          {showRugDetails && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-2.5 p-3 bg-zinc-900 border border-zinc-850 space-y-2 text-[10px] uppercase font-mono italic text-zinc-400"
            >
              <div className="flex justify-between border-b border-zinc-850 pb-1">
                <span>⚡ MINT AUTHORITY:</span>
                <span className="text-lime-400 font-bold">REVOKED ON-CHAIN</span>
              </div>
              <div className="flex justify-between border-b border-zinc-850 pb-1">
                <span>❄️ FREEZE AUTHORITY:</span>
                <span className="text-lime-400 font-bold">DISABLED ON-CHAIN</span>
              </div>
              <div className="flex justify-between border-b border-zinc-850 pb-1">
                <span>🔐 LP BINDING LOCK:</span>
                <span className="text-lime-400 font-black">{token.rugScore >= 80 ? "100% SECURE" : "UNSTABLE PRE-MIGRATION"}</span>
              </div>
              <div className="flex justify-between">
                <span>🐋 WHALE DISTRIBUTION:</span>
                <span className="text-zinc-300 font-black">{token.rugScore >= 80 ? "SAFE (< 12%)" : "CONCENTRATED"}</span>
              </div>
            </motion.div>
          )}
        </div>

        {/* Short description / narrative */}
        {token.description && (
          <p className="text-xs text-zinc-400 font-mono italic leading-relaxed bg-zinc-900/40 p-2.5 border border-zinc-850 rounded-none mb-4 uppercase">
            {token.description}
          </p>
        )}
      </div>

      {/* Wallet Simulation Purchase Row */}
      <div className="border-t-2 border-zinc-850 pt-4 mt-auto">
        {walletState.connected ? (
          <form onSubmit={executeSimulatedBuy} className="space-y-2.5">
            <div className="flex items-center justify-between gap-1.5 font-mono">
              <span className="text-[10px] font-black text-zinc-500 uppercase flex items-center gap-1">
                <Zap className="w-3 h-3 text-lime-400" /> ON-CHAIN RPC:
              </span>
              <div className="flex gap-1">
                {[0.1, 0.5, 1.0].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setBuyAmount(amt)}
                    className={`px-2 py-0.5 rounded-none text-[10px] font-black border transition-all cursor-pointer ${
                      buyAmount === amt 
                        ? "bg-lime-400 text-black border-lime-400" 
                        : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white"
                    }`}
                  >
                    {amt}
                  </button>
                ))}
                <span className="text-[10px] font-black text-zinc-400 pt-0.5 ml-0.5">SOL</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={buying}
              className="w-full py-2.5 bg-lime-400 hover:bg-lime-300 text-black font-mono font-black text-xs uppercase tracking-tight rounded-none transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 italic cursor-pointer"
            >
              {buying ? (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-black animate-ping"></span>
                  SNIPING BLOCK...
                </span>
              ) : (
                <>
                  <Coins className="w-3.5 h-3.5 text-black" />
                  <span>SNIPE NOW {buyAmount} SOL</span>
                </>
              )}
            </button>
          </form>
        ) : (
          <div className="text-center p-2.5 bg-zinc-900/60 border border-zinc-850 rounded-none">
            <p className="text-[10px] text-zinc-500 font-mono font-black uppercase tracking-wider leading-tight">
              CONNECT WALLET TO SIMULATE INSTANT SOL SNIPE
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
