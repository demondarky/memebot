import React, { useState } from "react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
} from "recharts";
import { TrendingUp, Award, BarChart3, PieChart as PieIcon, RefreshCw, Flame, Percent, Wallet, Sparkles } from "lucide-react";

interface AnalyticsPanelProps {
  globalWinRate: number;
  balanceSol: number;
}

export default function AnalyticsPanel({ globalWinRate, balanceSol }: AnalyticsPanelProps) {
  const [generationSalt, setGenerationSalt] = useState<number>(0);

  // 1. Hardcoded highly stylized mock sentiment datasets
  const sentimentData = [
    { name: "Bullish Sniper Pressure", value: 65 + (generationSalt % 5), color: "#a3e635" }, // Lime
    { name: "Neutral Range Consolidity", value: 20 - (generationSalt % 3), color: "#71717a" }, // Zinc-500
    { name: "Bearish Liquidity Pull", value: 15 - (generationSalt % 2), color: "#f43f5e" } // Rose-500
  ];

  const volumeTrends = [
    { day: "Day 1", Axiom: 1420 + (generationSalt * 50), PumpFun: 980 + (generationSalt * 30) },
    { day: "Day 2", Axiom: 1850 + (generationSalt * 40), PumpFun: 1240 + (generationSalt * 60) },
    { day: "Day 3", Axiom: 2100 + (generationSalt * 60), PumpFun: 1150 + (generationSalt * 20) },
    { day: "Day 4", Axiom: 2890 + (generationSalt * 80), PumpFun: 1680 + (generationSalt * 90) },
    { day: "Day 5", Axiom: 3240 + (generationSalt * 40), PumpFun: 2100 + (generationSalt * 110) },
    { day: "Day 6", Axiom: 3980 + (generationSalt * 90), PumpFun: 2450 + (generationSalt * 50) },
    { day: "Day 7", Axiom: 4500 + (generationSalt * 120), PumpFun: 2900 + (generationSalt * 140) }
  ];

  // 2. Generate 30 Days of Wallet growth ending exactly at current balanceSol
  const walletGrowthData = Array.from({ length: 30 }, (_, index) => {
    const dayAgo = 29 - index;
    const date = new Date();
    date.setDate(date.getDate() - dayAgo);
    const label = date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    
    // Create an upward trading trajectory leading to their wallet balance
    const progress = index / 29;
    const multiplier = 0.3 + (0.7 * progress);
    const oscillation = Math.sin((index + generationSalt) * 0.8) * 0.05 * (1 - progress); 
    const calculatedBackpoint = balanceSol * Math.max(0.1, multiplier + oscillation);

    return {
      date: label,
      "Wallet SOL": parseFloat(calculatedBackpoint.toFixed(4))
    };
  });

  // Dynamically build win rate history curve
  const step = (globalWinRate - 60) / 6;
  const winRateHistory = [
    { period: "Phase Alpha", WinRate: parseFloat((60).toFixed(1)) },
    { period: "Phase Beta", WinRate: parseFloat((60 + step).toFixed(1)) },
    { period: "Phase Gamma", WinRate: parseFloat((60 + step * 2).toFixed(1)) },
    { period: "Phase Delta", WinRate: parseFloat((60 + step * 3).toFixed(1)) },
    { period: "Phase Epsilon", WinRate: parseFloat((60 + step * 4).toFixed(1)) },
    { period: "Phase Zeta", WinRate: parseFloat((60 + step * 5).toFixed(1)) },
    { period: "Current Node", WinRate: parseFloat(globalWinRate.toFixed(1)) }
  ];

  // Illustrative example data only — NOT real trades, callers, or returns.
  // Clearly labeled in the UI below so this can't be mistaken for a live
  // social-proof feed (a pattern often used to manufacture false credibility).
  const bestCalls = [
    { rank: 1, caller: "example_caller_1", token: "WIF", txId: "7FCmp...ySDF98", multiplier: "24.5x", ROI: "+2350%", date: "example", allocation: "1.25 SOL" },
    { rank: 2, caller: "example_caller_2", token: "POPCAT", txId: "DezXA...hCO68", multiplier: "16.8x", ROI: "+1580%", date: "example", allocation: "0.80 SOL" },
    { rank: 3, caller: "example_caller_3", token: "BONK", txId: "7GCih...fCO68", multiplier: "12.4x", ROI: "+1140%", date: "example", allocation: "2.50 SOL" },
    { rank: 4, caller: "example_caller_4", token: "BOME", txId: "ukHH6...3199Y", multiplier: "8.2x", ROI: "+720%", date: "example", allocation: "0.45 SOL" },
    { rank: 5, caller: "example_caller_5", token: "Axiom Doge", txId: "7FCmp...F89yS", multiplier: "5.4x", ROI: "+440%", date: "example", allocation: "1.50 SOL" }
  ];

  // Custom styling elements for Recharts Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-zinc-950 border border-zinc-800 p-3 font-mono text-[10px] uppercase space-y-1 shadow-2xl rounded-none">
          <p className="text-zinc-550 font-black tracking-wider text-lime-400">{label}</p>
          {payload.map((item: any, idx: number) => (
            <p key={idx} style={{ color: item.color || "#a3e635" }} className="font-extrabold flex items-center gap-1.5">
              <span>{item.name || "Value"}:</span>
              <span className="text-white">{item.value} {item.name && item.name.toLowerCase().includes("win") ? "%" : "SOL"}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* HEADER HUD BAR */}
      <div className="bg-zinc-900 border-2 border-zinc-850 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-2xl relative">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="bg-lime-400 text-black font-mono font-black text-[9px] uppercase px-2 py-0.5 rounded-none">
              ANALYTICS INTEGRATION v2.0
            </span>
            <span className="text-zinc-500 font-mono text-[9px] tracking-widest">// SECURE DIAGNOSTIC NODE //</span>
          </div>
          <h2 className="text-2xl font-display font-black tracking-tight uppercase italic text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-lime-400" />
            MARKET SENTIMENT & VOLUMETRIC ANALYSIS
          </h2>
          <p className="text-xs text-zinc-400 font-sans uppercase tracking-wider max-w-2xl leading-relaxed">
            Real-time visual diagnostic mapping of order-book flow indices, user portfolio balance growth trends, and highest performing call execution leaders.
          </p>
        </div>

        <button
          onClick={() => setGenerationSalt(prev => prev + 1)}
          className="flex items-center gap-2 px-5 py-3 border-2 border-zinc-800 hover:border-lime-400 bg-zinc-950 hover:bg-zinc-900 font-mono text-xs font-black uppercase text-lime-400 cursor-pointer shadow-[0_0_15px_rgba(163,230,53,0.05)] hover:shadow-[0_0_20px_#a3e635] transition-all shrink-0"
        >
          <RefreshCw className="w-4 h-4 animate-spin-slow" />
          REFRESH SNIPER METRICS
        </button>
      </div>

      {/* THREE BENTO WIDGETS DISPLAYING CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* CHART 1: EXAMPLE WALLET BALANCE TRAJECTORY (illustrative, not real history) */}
        <div className="lg:col-span-12 bg-zinc-950 border-2 border-zinc-850 p-6 shadow-2xl space-y-4">
          <div className="flex justify-between items-center border-b border-zinc-850 pb-3 flex-wrap gap-2">
            <div className="space-y-1">
              <span className="text-xs font-mono text-amber-400 uppercase tracking-widest block font-bold">// EXAMPLE CHART, NOT REAL HISTORY //</span>
              <h3 className="font-display text-base font-black uppercase italic text-white flex items-center gap-2">
                <Wallet className="w-5 h-5 text-lime-400" />
                Example 30-Day Balance Trajectory (SOL)
              </h3>
              <p className="text-[10px] text-zinc-500 uppercase tracking-tight font-mono">
                Illustrative curve only. This app does not track or store your real trade history.
              </p>
            </div>
            <div className="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-none text-right">
              <span className="text-[10px] text-zinc-500 block uppercase font-mono">YOUR CONNECTED WALLET BALANCE:</span>
              <span className="text-sm font-mono font-black text-lime-400">{balanceSol.toFixed(4)} SOL</span>
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={walletGrowthData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradientWalletGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a3e635" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#a3e635" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222225" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#71717a" 
                  fontSize={10} 
                  fontFamily="monospace" 
                  tickLine={false} 
                />
                <YAxis 
                  stroke="#71717a" 
                  fontSize={10} 
                  fontFamily="monospace" 
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#a3e635', strokeWidth: 1 }} />
                <Area 
                  type="monotone" 
                  dataKey="Wallet SOL" 
                  name="Solana Balance" 
                  stroke="#a3e635" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#gradientWalletGrad)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="pt-2 border-t border-zinc-900 text-[10px] text-zinc-500 flex justify-between font-mono">
            <span>EXAMPLE TRAJECTORY — NOT YOUR REAL HISTORY</span>
            <span className="text-amber-400">ILLUSTRATIVE ONLY</span>
          </div>
        </div>

        {/* CHART 2: VOLUME TRENDS AXIOM VS PUMP.FUN - 7 COLUMNS */}
        <div className="lg:col-span-7 bg-zinc-950 border-2 border-zinc-850 p-6 shadow-2xl space-y-4">
          <div className="flex justify-between items-center border-b border-zinc-850 pb-3 flex-wrap gap-2">
            <div className="space-y-1">
              <h3 className="font-display text-sm font-black uppercase italic text-white flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-lime-400" />
                Cross-DEX Volumetric Flow (SOL)
              </h3>
              <p className="text-[10px] text-zinc-500 uppercase tracking-tight font-mono">
                Volume density comparison between Axiom Pre-Dex pools and Pump.fun curves.
              </p>
            </div>
            <div className="flex gap-4 text-[9px] font-mono uppercase bg-zinc-900 p-2 border border-zinc-800">
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-lime-400 block" /> Axiom</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-blue-400 block" /> Pump.fun</span>
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={volumeTrends} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradientAxiom" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a3e635" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#a3e635" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="gradientPump" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#60a5fa" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis 
                  dataKey="day" 
                  stroke="#71717a" 
                  fontSize={10} 
                  fontFamily="monospace" 
                  tickLine={false} 
                />
                <YAxis 
                  stroke="#71717a" 
                  fontSize={10} 
                  fontFamily="monospace" 
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#a3e635', strokeWidth: 1 }} />
                <Area 
                  type="monotone" 
                  dataKey="Axiom" 
                  name="Axiom Vol" 
                  stroke="#a3e635" 
                  strokeWidth={2.5} 
                  fillOpacity={1} 
                  fill="url(#gradientAxiom)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="PumpFun" 
                  name="Pump.fun Vol" 
                  stroke="#60a5fa" 
                  strokeWidth={2} 
                  fillOpacity={1} 
                  fill="url(#gradientPump)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="pt-2 border-t border-zinc-900 text-[10px] text-zinc-500 flex justify-between font-mono">
            <span>EXAMPLE DATA — NOT LIVE</span>
            <span className="text-amber-400">ILLUSTRATIVE ONLY</span>
          </div>
        </div>

        {/* CHART 3: PIE - MARKET SENTIMENT DISTRIBUTION - 5 COLUMNS */}
        <div className="lg:col-span-5 bg-zinc-950 border-2 border-zinc-850 p-6 shadow-2xl space-y-4">
          <div className="space-y-1 border-b border-zinc-850 pb-3">
            <h3 className="font-display text-sm font-black uppercase italic text-white flex items-center gap-1.5">
              <PieIcon className="w-4 h-4 text-lime-400" />
              Sentiment Map (Example)
            </h3>
            <p className="text-[10px] text-zinc-500 uppercase tracking-tight font-mono">
              Illustrative placeholder ratio — not derived from live order flow.
            </p>
          </div>

          <div className="h-64 flex justify-center items-center relative pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            
            {/* Absolute indicator center text */}
            <div className="absolute text-center">
              <span className="text-[10px] text-zinc-500 font-mono block uppercase">BULL/BEAR</span>
              <span className="text-xl font-mono font-black text-lime-400 italic">
                {sentimentData[0].value}:{sentimentData[2].value}
              </span>
            </div>
          </div>

          <div className="space-y-2 pt-1 border-t border-zinc-900 font-mono text-[10px] uppercase">
            {sentimentData.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-zinc-400">
                <span className="flex items-center gap-2 font-semibold">
                  <span className="w-2.5 h-2.5" style={{ backgroundColor: item.color }} />
                  {item.name}
                </span>
                <span className="font-black text-white">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* BEST CALLS LEADERBOARD SECTION (NEW REQ SPECIFICATION) */}
      <div className="bg-zinc-950 border-2 border-zinc-850 p-6 shadow-2xl space-y-4">
        <div className="border-b border-zinc-850 pb-3 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div className="space-y-1">
            <span className="text-xs font-mono text-amber-400 uppercase tracking-widest block font-bold">// SAMPLE DATA, NOT LIVE //</span>
            <h3 className="font-display text-base font-black uppercase italic text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-lime-400" />
              EXAMPLE LEADERBOARD LAYOUT
            </h3>
            <p className="text-[10px] text-zinc-500 uppercase tracking-tight font-mono">
              Illustrative placeholder rows showing how a calls leaderboard could be laid out. These are not real traders, real transactions, or real returns.
            </p>
          </div>
          <div className="px-2.5 py-1.5 bg-zinc-800 text-amber-400 border border-amber-900/40 uppercase font-mono text-[10px] font-black italic flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> DEMO / PLACEHOLDER DATA
          </div>
        </div>

        {/* LEADERBOARD TABLE GRID */}
        <div className="overflow-x-auto border border-zinc-850">
          <table className="w-full text-left border-collapse bg-zinc-900/50">
            <thead>
              <tr className="border-b border-zinc-850 bg-zinc-900 font-mono text-[10px] text-zinc-500 uppercase">
                <th className="p-3 text-center w-12">RANK</th>
                <th className="p-3">CALLER COGNIZANT</th>
                <th className="p-3">MEMECOIN</th>
                <th className="p-3">TX HASH</th>
                <th className="p-3">ALLOCATION</th>
                <th className="p-3 text-center">MULTIPLIER</th>
                <th className="p-3 text-right">NET RETURN ROI</th>
                <th className="p-3 text-right">AGE / DATE</th>
              </tr>
            </thead>
            <tbody className="font-mono text-[11px] uppercase divide-y divide-zinc-850/60">
              {bestCalls.map((call, idx) => (
                <tr 
                  key={call.rank}
                  className="hover:bg-zinc-850/40 transition-colors"
                >
                  <td className="p-3 text-center">
                    <span className={`inline-block w-6 py-0.5 font-bold rounded-none ${
                      idx === 0 
                        ? "bg-lime-400 text-black" 
                        : idx === 1 
                          ? "bg-zinc-700 text-white" 
                          : "bg-zinc-800 text-zinc-400"
                    }`}>
                      #{call.rank}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-zinc-200">
                    {call.caller}
                  </td>
                  <td className="p-3 font-extrabold text-white flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-pulse" />
                    {call.token}
                  </td>
                  <td className="p-3 text-zinc-500 text-[10px]">
                    {call.txId}
                  </td>
                  <td className="p-3 text-zinc-350">
                    {call.allocation}
                  </td>
                  <td className="p-3 text-center">
                    <span className="font-black text-lime-400 bg-lime-950/15 border border-lime-900/25 px-1.5 py-0.5 text-[10px]">
                      {call.multiplier}
                    </span>
                  </td>
                  <td className="p-3 text-right font-black text-lime-400">
                    {call.ROI}
                  </td>
                  <td className="p-3 text-right text-zinc-500 italic text-[10px]">
                    {call.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CHART 4: ACCUMULATED SNIPE WIN-RATE GROWTH CURVE */}
      <div className="bg-zinc-950 border-2 border-zinc-850 p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-zinc-850 pb-3 gap-3">
          <div className="space-y-1">
            <h3 className="font-display text-sm font-black uppercase italic text-white flex items-center gap-1.5">
              <Percent className="w-4 h-4 text-lime-400" />
              Aggregated Win-Rate Optimization Curve
            </h3>
            <p className="text-[10px] text-zinc-500 uppercase tracking-tight font-mono">
              Visualizing the auto-sniper predictive model enhancements and positive EV trends over consecutive runs.
            </p>
          </div>
          <div className="px-3 py-1 bg-lime-400/10 border border-lime-400 text-lime-400 font-mono text-xs font-black uppercase italic">
            CURRENT EV CAP: {globalWinRate}% ACCURACY
          </div>
        </div>

        <div className="h-72 w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={winRateHistory} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222225" vertical={false} />
              <XAxis 
                dataKey="period" 
                stroke="#71717a" 
                fontSize={10} 
                fontFamily="monospace" 
                tickLine={false} 
              />
              <YAxis 
                stroke="#71717a" 
                fontSize={10} 
                fontFamily="monospace" 
                tickLine={false}
                axisLine={false}
                domain={[50, 95]}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#a3e635', strokeWidth: 1 }} />
              <Line 
                type="monotone" 
                dataKey="WinRate" 
                name="Win Rate" 
                stroke="#a3e635" 
                strokeWidth={3} 
                dot={{ r: 4, stroke: '#a3e635', strokeWidth: 2, fill: '#09090b' }}
                activeDot={{ r: 6, stroke: '#09090b', strokeWidth: 2, fill: '#a3e635' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-zinc-900 text-[10px] text-zinc-500 font-mono uppercase">
          <div className="bg-zinc-900 p-3 border border-zinc-850">
            <span className="text-zinc-600 font-black block">CHART STYLE:</span>
            <span className="text-white text-xs font-black">ILLUSTRATIVE EXAMPLE</span>
          </div>
          <div className="bg-zinc-900 p-3 border border-zinc-850">
            <span className="text-zinc-600 font-black block">SAMPLE PERIOD SHOWN:</span>
            <span className="text-white text-xs font-black">7 EXAMPLE PHASES</span>
          </div>
          <div className="bg-zinc-900 p-3 border border-zinc-850">
            <span className="text-zinc-600 font-black block">CURRENT LIVE WIN RATE:</span>
            <span className="text-lime-400 text-xs font-black">{globalWinRate}% (FROM TOKEN FEED)</span>
          </div>
        </div>
      </div>

    </div>
  );
}
