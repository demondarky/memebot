import React from "react";
import { motion } from "motion/react";
import { Wallet, X, CheckCircle2, ShieldCheck } from "lucide-react";
import { useWallet } from "@solana/wallet-adapter-react";
import { useWalletModal } from "@solana/wallet-adapter-react-ui";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// This modal hands off to the real Solana wallet-adapter connect flow.
// Phantom / Solflare (or any other adapter-compatible wallet extension)
// handles the actual connection, balance, and signing — this app never
// sees, requests, or stores a private key or seed phrase at any point.
export default function WalletModal({ isOpen, onClose }: WalletModalProps) {
  const { wallets, select, connecting, connected } = useWallet();
  const { setVisible } = useWalletModal();

  if (!isOpen) return null;

  const handleConnectClick = () => {
    // Defer to wallet-adapter's own battle-tested connect modal, which
    // lists installed wallets and handles the extension handshake itself.
    setVisible(true);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-lg bg-zinc-950 border-2 border-zinc-800 rounded-none overflow-hidden shadow-2xl"
      >
        <div className="p-5 border-b-2 border-zinc-800 flex justify-between items-center bg-zinc-900">
          <div className="flex items-center gap-2">
            <div className="bg-lime-400 text-black px-2 py-0.5 font-black uppercase text-xs italic tracking-tighter">
              WALLET
            </div>
            <h3 className="text-sm font-mono font-black text-white uppercase tracking-wider">
              CONNECT SOLANA WALLET
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white transition-colors p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-zinc-900/85 border border-zinc-800 p-3.5 text-[10px] font-mono text-zinc-400 rounded-none leading-relaxed uppercase">
            <div className="flex items-center gap-1.5 text-lime-400 font-extrabold mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-lime-400 shrink-0" />
              <span>HOW THIS WORKS:</span>
            </div>
            Connecting opens your wallet extension directly (Phantom, Solflare, etc).
            Your private key and seed phrase always stay inside that extension —
            this app only ever receives your public address and can request
            transactions that you individually approve. Nothing is signed or
            sent without your explicit confirmation in the extension popup.
          </div>

          <button
            type="button"
            onClick={handleConnectClick}
            disabled={connecting}
            className="w-full flex items-center justify-between p-4 rounded-none border-2 border-zinc-800 bg-zinc-900 hover:bg-zinc-900/80 hover:border-lime-400 text-left transition-all cursor-pointer disabled:opacity-50"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-none bg-zinc-950 border border-zinc-800 flex items-center justify-center">
                <Wallet className="w-5 h-5 text-lime-400" />
              </div>
              <div>
                <h4 className="font-mono text-sm font-black uppercase italic tracking-tight text-white">
                  Choose Wallet
                </h4>
                <p className="text-[10px] text-zinc-500 uppercase tracking-tight">
                  {wallets.length > 0
                    ? `${wallets.length} wallet${wallets.length === 1 ? "" : "s"} detected`
                    : "Opens Phantom / Solflare connect flow"}
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 border border-zinc-700 text-lime-400 font-bold uppercase tracking-tight">
              {connected ? "Connected" : "Connect"}
            </span>
          </button>

          <div className="flex items-center gap-2 mt-4 p-3 bg-zinc-900 border border-zinc-800 rounded-none">
            <CheckCircle2 className="w-4 h-4 text-lime-400 shrink-0" />
            <p className="text-[10px] text-zinc-300 font-mono uppercase tracking-tight leading-tight">
              Don't have a wallet yet? The connect flow will offer to install Phantom or Solflare for you.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
